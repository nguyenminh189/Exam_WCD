package com.example.examwcd.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Player {
    private Long player_id;
    private String name;
    private String full_name;
    private Long age;
    private Long index_id;

}
