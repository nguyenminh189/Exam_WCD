package com.example.examwcd.dao;

import com.example.examwcd.database.Database;
import com.example.examwcd.entity.Player;
import com.example.examwcd.entity.PlayerIndex;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PlayerDAO implements DAOinterface<Player, Long> {
    public List<Player> all() {
    List<Player> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM player_evaluation";
            Database db = Database.createInstance();
            Statement st = db.getStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                list.add(new Player(
                        rs.getLong("player_id"),
                        rs.getString("name"),
                        rs.getString("full_name"),
                        rs.getLong("age"),
                        rs.getLong("index_id")
                ));
            }
        }catch (Exception e){

        }
        return list;
    }

    @Override
    public void create(Player player) {
        try {
            String sql = "INSERT INTO player_evaluation (name, full_name, age, index_id) VALUES (?, ?, ?, ?)";
            Database db = Database.createInstance();
            PreparedStatement ps = db.getPreparedStatement(sql);
            ps.setString(1, player.getName());
            ps.setString(2, player.getFull_name());
            ps.setLong(3, player.getAge());
            ps.setLong(4, player.getIndex_id());

            ps.executeUpdate();
            System.out.println("Player created successfully!");
        } catch (SQLException e) {
            System.err.println("Error creating player: " + e.getMessage());
        }
    }

    @Override
    public void update(Player player) {
        try {
            String sql = "UPDATE player_evaluation SET name = ?, full_name = ?, age = ?, index_id = ? WHERE player_id = ?";
            Database db = Database.createInstance();
            PreparedStatement ps = db.getPreparedStatement(sql);
            ps.setString(1, player.getName());
            ps.setString(2, player.getFull_name());
            ps.setLong(3, player.getAge());
            ps.setLong(4, player.getIndex_id());
            ps.setLong(5, player.getPlayer_id());

            ps.executeUpdate();
            System.out.println("Player updated successfully!");
        } catch (SQLException e) {
            System.err.println("Error updating player: " + e.getMessage());
        }
    }

    @Override
    public void delete(Long id) {
        try {
            String sql = "DELETE FROM player_evaluation WHERE player_id = ?";
            Database db = Database.createInstance();
            PreparedStatement ps = db.getPreparedStatement(sql);
            ps.setLong(1, id);

            ps.executeUpdate();
            System.out.println("Player deleted successfully!");
        } catch (SQLException e) {
            System.err.println("Error deleting player: " + e.getMessage());
        }
    }

    @Override
    public Player find(Long id) {
        Player player = null;
        try {
            String sql = "SELECT * FROM player_evaluation WHERE player_id = ?";
            Database db = Database.createInstance();
            PreparedStatement ps = db.getPreparedStatement(sql);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                player = new Player(
                        rs.getLong("player_id"),
                        rs.getString("name"),
                        rs.getString("full_name"),
                        rs.getLong("age"),
                        rs.getLong("index_id")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error finding player: " + e.getMessage());
        }
        return null;
    }

    public void savePlayerIndex(PlayerIndex playerIndex) {
        try {
            String sql = "INSERT INTO player_index (player_id, index_id, value) VALUES (?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE value = ?";
            Database db = Database.createInstance();
            PreparedStatement ps = db.getPreparedStatement(sql);
            ps.setLong(1, playerIndex.getPlayer_id());
            ps.setLong(2, playerIndex.getIndex_id());
            ps.setFloat(3, playerIndex.getValue());
            ps.setFloat(4, playerIndex.getValue());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error saving: " + e.getMessage());
        }
    }

    public Float getPlayerIndexValue(Long player_id, Long index_id) {
        try {
            String sql = "SELECT value FROM player_index WHERE player_id = ? AND index_id = ?";
            Database db = Database.createInstance();
            PreparedStatement ps = db.getPreparedStatement(sql);
            ps.setLong(1, player_id);
            ps.setLong(2, index_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getFloat("value");
            }
        } catch (SQLException e) {
            System.err.println("Error getting player: " + e.getMessage());
        }
        return null;
    }

}
