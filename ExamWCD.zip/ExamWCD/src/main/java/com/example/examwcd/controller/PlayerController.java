package com.example.examwcd.controller;

import com.example.examwcd.dao.PlayerDAO;
import com.example.examwcd.entity.Player;
import com.example.examwcd.entity.PlayerIndex;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(value = "player")
public class PlayerController extends HttpServlet {
    private PlayerDAO playerDAO;
    @Override
    public void init() throws ServletException {
        playerDAO = new PlayerDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deletePlayer(request, response);
                break;
            default:
                listPlayers(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "create";
        }

        switch (action) {
            case "create":
                createPlayer(request, response);
                break;
            case "update":
                updatePlayer(request, response);
                break;
            case "saveIndex":
                savePlayerIndex(request, response);
                break;
            default:
                listPlayers(request, response);
                break;
        }
    }


    private void listPlayers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Player> players = playerDAO.all();
        request.setAttribute("players", players);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/player-list.jsp");
        dispatcher.forward(request, response);
    }

    private void createPlayer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = request.getParameter("name");
        String fullName = request.getParameter("full_name");
        Long age = Long.parseLong(request.getParameter("age"));
        Long indexId = Long.parseLong(request.getParameter("index_id"));

        Player player = new Player(null, name, fullName, age, indexId);
        playerDAO.create(player);
        response.sendRedirect("players");
    }

    private void updatePlayer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long id = Long.parseLong(request.getParameter("player_id"));
        String name = request.getParameter("name");
        String fullName = request.getParameter("full_name");
        Long age = Long.parseLong(request.getParameter("age"));
        Long indexId = Long.parseLong(request.getParameter("index_id"));

        Player player = new Player(id, name, fullName, age, indexId);
        playerDAO.update(player);
        response.sendRedirect("players");
    }

    private void deletePlayer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long id = Long.parseLong(request.getParameter("player_id"));
        playerDAO.delete(id);
        response.sendRedirect("players");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("player_id"));
        Player existingPlayer = playerDAO.find(id);
        request.setAttribute("player", existingPlayer);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/player-form.jsp");
        dispatcher.forward(request, response);
    }

    private void savePlayerIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long player_id = Long.parseLong(request.getParameter("player_id"));
        Long index_id = Long.parseLong(request.getParameter("index_id"));
        Float value = Float.parseFloat(request.getParameter("value"));

        PlayerIndex playerIndex = new PlayerIndex(null, player_id, index_id, value);
        playerDAO.savePlayerIndex(playerIndex);
        response.sendRedirect("players");
    }

}
