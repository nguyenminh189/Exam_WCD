package com.example.examwcd.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@AllArgsConstructor
public class Indexer {
    private Long index_id;
    private String name;
    private Float valueMin;
    private Float valueMax;

    public Long getIndex_id() {
        return index_id;
    }

    public void setIndex_id(Long index_id) {
        this.index_id = index_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getValueMin() {
        return valueMin;
    }

    public void setValueMin(Float valueMin) {
        this.valueMin = valueMin;
    }

    public Float getValueMax() {
        return valueMax;
    }

    public void setValueMax(Float valueMax) {
        this.valueMax = valueMax;
    }
}
